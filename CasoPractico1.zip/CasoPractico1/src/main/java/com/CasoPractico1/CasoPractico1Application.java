package com.CasoPractico1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasoPractico1Application {

	public static void main(String[] args) {
		SpringApplication.run(CasoPractico1Application.class, args);
	}

}
