package com.CasoPractico1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasoPractico1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
