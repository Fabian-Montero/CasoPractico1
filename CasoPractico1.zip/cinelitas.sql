create database cinelitas;
use cinelitas;

create table salas(
id_sala int not null auto_increment primary key,
nombre varchar (50) not null,
capacidad_maxima int not null
);
insert into salas (nombre,capacidad_maxima)
values ("Sala 3",50);




create table peliculas(
id_pelicula int NOT NULL AUTO_INCREMENT primary key,
nombre varchar (50) not null,
costo_entrada int not null,
fecha date not null,
id_sala int not null,
foreign key (id_sala) references salas(id_sala)
);

insert into peliculas(nombre,costo_entrada,fecha,id_sala)
values ("Harry Potter", 10000, STR_TO_DATE('08/03/2023','%d/%m/%Y'), 1);

